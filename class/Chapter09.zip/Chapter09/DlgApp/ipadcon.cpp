// ipadcon.cpp : implementation file
//

#include "stdafx.h"
#include "ipadcon.h"
#include "afxdialogex.h"


// ipadcon dialog

IMPLEMENT_DYNAMIC(ipadcon, CDialogEx)

ipadcon::ipadcon(CWnd* pParent /*=NULL*/)
	: CDialogEx(ipadcon::IDD, pParent)
{

}

ipadcon::~ipadcon()
{
}

void ipadcon::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(ipadcon, CDialogEx)
END_MESSAGE_MAP()


// ipadcon message handlers
