pragma once
#include <afxcontrolbars.h>
